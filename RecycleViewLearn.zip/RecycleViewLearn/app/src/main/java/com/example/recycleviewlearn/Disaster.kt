package com.example.recycleviewlearn

data class Disaster (
    val imageUrl: String="",
    val nameDisaster: String="",
    val typeDisaster: String=""
)