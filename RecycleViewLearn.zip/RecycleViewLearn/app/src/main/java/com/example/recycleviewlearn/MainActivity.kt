package com.example.recycleviewlearn

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.bumptech.glide.request.RequestOptions
import androidx.recyclerview.widget.GridLayoutManager
import com.example.recycleviewlearn.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    // Inisialisasi binding untuk mengikat tata letak aktivitas
    private lateinit var binding: ActivityMainBinding

    // Metode onCreate dipanggil ketika aktivitas dibuat
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Membuat adapter untuk daftar bencana dengan data yang dihasilkan secara palsu
        val adapterDisaster = DisasterAdapter(generateDummy()) {disaster ->
            // Menampilkan pesan Toast saat item diklik
            Toast.makeText(this@MainActivity, "This is a ${disaster.nameDisaster} accident",
            Toast.LENGTH_SHORT).show()
        }

        // Mengonfigurasi RecyclerView dengan adapter dan layout manager
        with(binding) {
            rvDisaster.apply {
                adapter = adapterDisaster
                layoutManager = GridLayoutManager(this@MainActivity, 1)
            }
        }
    }

    // Metode untuk menghasilkan data palsu untuk daftar bencana
    fun generateDummy(): List<Disaster> {
        return listOf(
            // Daftar objek Disaster dengan nama, jenis, dan URL gambar yang diberikan
            Disaster(nameDisaster = "Tsunami", typeDisaster = "Natural", imageUrl = "https://images.unsplash.com/photo-1614678031696-2d07467a6ebf?auto=format&fit=crop&q=80&w=2874&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"),
            Disaster(nameDisaster = "Volcanic Eruption", typeDisaster = "Natural", imageUrl = "https://images.unsplash.com/photo-1580250642511-1660fe42ad58?q=80&w=1325&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"),
            Disaster(nameDisaster = "Earthquake", typeDisaster = "Natural", imageUrl = "https://images.unsplash.com/photo-1621077742331-2df96a07cca7?w=1400&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8ZWFydGhxdWFrZXxlbnwwfHwwfHx8MA%3D%3D"),
            Disaster(nameDisaster = "Flood", typeDisaster = "Natural", imageUrl = "https://images.unsplash.com/photo-1604275689235-fdc521556c16?w=1400&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8Zmxvb2R8ZW58MHx8MHx8fDA%3D"),
            Disaster(nameDisaster = "Fire", typeDisaster = "Natural", imageUrl = "https://images.unsplash.com/photo-1507680465142-ef2223e23308?w=1400&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8d2lsZGZpcmV8ZW58MHx8MHx8fDA%3D"),
            Disaster(nameDisaster = "Nuclear Accident", typeDisaster = "Man-made", imageUrl = "https://images.unsplash.com/photo-1517925035435-7976539b920d?w=1400&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fG51Y2xlYXIlMjBhY2NpZGVudHxlbnwwfHwwfHx8MA%3D%3D"),
            Disaster(nameDisaster = "Terrorist Attack", typeDisaster = "Man-made", imageUrl = "https://images.unsplash.com/photo-1563804951831-49844db19644?w=1400&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8dGVycm9yaXN0JTIwYXR0YWNrfGVufDB8fDB8fHww"),
            Disaster(nameDisaster = "War", typeDisaster = "Man-made", imageUrl = "https://images.unsplash.com/photo-1579912436616-f74ceee1ae07?w=1400&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MzR8fHdhcnxlbnwwfHwwfHx8MA%3D%3D")
        )
    }
}