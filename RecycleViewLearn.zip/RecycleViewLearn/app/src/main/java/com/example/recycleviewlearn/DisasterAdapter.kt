package com.example.recycleviewlearn

import android.view.LayoutInflater
import android.view.ViewGroup
import com.bumptech.glide.Glide
import androidx.recyclerview.widget.RecyclerView
import com.example.recycleviewlearn.databinding.ItemDisasterBinding

// Menggunakan typealias untuk mempermudah penggunaan onClickListener
typealias onClickDisaster = (Disaster) -> Unit

class DisasterAdapter (private  val listDisaster: List<Disaster>,
    private val onClickDisaster: onClickDisaster) :
    RecyclerView.Adapter<DisasterAdapter.ItemDisasterViewHolder>() {
    // ViewHolder untuk setiap item dalam RecyclerView
    inner class ItemDisasterViewHolder (private val binding :
        ItemDisasterBinding) : RecyclerView.ViewHolder(binding.root) {

        // Inisialisasi onClickListener untuk gambar di setiap item
        init {
            binding.imgDisaster.setOnClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    val disaster = listDisaster[position]
                    onClickDisaster(disaster)
                }
            }
        }

        // Mengikat data ke tampilan setiap item
        fun bind (data: Disaster) {
                with(binding) {
                    txtDisasterName.text = data.nameDisaster
                    txtDisasterType.text = data.typeDisaster
                    // Menggunakan Glide untuk memuat gambar dari URL ke ImageView
                    Glide.with(itemView)
                        .load(data.imageUrl)
                        .centerCrop()
                        .into(imgDisaster)
                    // Menetapkan onClickListener untuk seluruh item
                    itemView.setOnClickListener{
                        onClickDisaster(data)
                    }
                }
            }
        }

    // Membuat ViewHolder baru berdasarkan layout yang diberikan
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemDisasterViewHolder {
        val binding = ItemDisasterBinding.inflate(LayoutInflater.from(parent.context),
            parent, false)
        return ItemDisasterViewHolder(binding)
    }

    // Mengembalikan jumlah item dalam daftar
    override fun getItemCount(): Int = listDisaster.size

    // Mengikat data ke ViewHolder pada posisi tertentu
    override fun onBindViewHolder(holder: ItemDisasterViewHolder, position: Int) {
        holder.bind(listDisaster[position])
    }
}